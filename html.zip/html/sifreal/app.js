
// create our angular app and inject ngAnimate and ui-router 
// =============================================================================
angular.module('formApp', ['ngAnimate', 'ui.router'])

// configuring our routes 
// =============================================================================
.config(function($stateProvider, $urlRouterProvider) {
    
    $stateProvider
    
        // route to show our basic form (/form)
        .state('asbu-sifre-alma-sihirbazi', {
            url: '/asbu-sifre-alma-sihirbazi',
            templateUrl: 'asbu-sifre-alma-sihirbazi.html',
            controller: 'formController'
        })
        
       
     
       
    // catch all route
    // send users to the form page 
    $urlRouterProvider.otherwise('/asbu-sifre-alma-sihirbazi');
})


    .controller('formController', function ($scope) {
        var enSonAdimlar = [];
        
        $scope.adim = "2";
        enSonAdimlar.push($scope.adim);
        $scope.stepData = { turkiyedeMisinizEvet: false, turkiyedeMisinizHayir: false }

        
    // we will store all of our form data in this object
    $scope.formData = {};
    
    // function to process the form
    $scope.processForm = function() {
      //  $scope.adim = $scope.adim + 1; 
    };
        $scope.ileri1 = function () {

            $scope.adim = "2";
            enSonAdimlar.push($scope.adim);

            $scope.stepData.turkiyedeMisinizEvet = false;
            $scope.stepData.turkiyedeMisinizHayir = false;
              
        };
  

        $scope.ileri = function () {
          
            //  $scope.adim = $scope.adim + 1;
            if ($scope.stepData.turkiyedeMisinizEvet === "true") {
                $scope.adim = $scope.adim + "1";
                enSonAdimlar.push($scope.adim);

            }
            if ($scope.stepData.turkiyedeMisinizHayir === "true") {
                $scope.adim = $scope.adim + "0";
                enSonAdimlar.push($scope.adim);

            }
            if ($scope.stepData.turkiyedeMisinizHayir == false && $scope.stepData.turkiyedeMisinizEvet == false) {
            //    alert();
            }

        
               

            
            
            $scope.stepData.turkiyedeMisinizEvet = false;
            $scope.stepData.turkiyedeMisinizHayir = false;
          
        };
        $scope.geri = function () {
      
            if (enSonAdimlar.length > 1) {



                $scope.adim = enSonAdimlar[enSonAdimlar.length - 2];
                enSonAdimlar.splice( enSonAdimlar.length - 1,1);
            
                //   enSonAdimlar.push($scope.adim);
            } else {
                $scope.adim = enSonAdimlar[enSonAdimlar.length - 1];
                
            }


            $scope.stepData.turkiyedeMisinizEvet = false;
            $scope.stepData.turkiyedeMisinizHayir = false;
        };
        $scope.islemleriTekrarla = function () {

         

            $scope.adim = "2";
               
                enSonAdimlar = [];


                enSonAdimlar.push($scope.adim);
            
            $scope.stepData.turkiyedeMisinizEvet = false;
            $scope.stepData.turkiyedeMisinizHayir = false;


        };

        

        $scope.basaAl = function () {
            //  $scope.adim = $scope.adim + 1;
            if ($scope.stepData.turkiyedeMisinizEvet === "true") {
                if ($scope.adim === "20010") {
                    $scope.adim = "20";
                    enSonAdimlar.push($scope.adim);

                }


                if ($scope.adim === "21010") {
                    $scope.adim = "21";
                    enSonAdimlar.push($scope.adim);

                }

                if ($scope.adim === "21011") {

                    $scope.adim = "21";
                    enSonAdimlar.push($scope.adim);


                }
                if ($scope.adim === "2100") {

                    $scope.adim = "21";
                    enSonAdimlar.push($scope.adim);


                }

               

            }

           

            $scope.stepData.turkiyedeMisinizEvet = false;
            $scope.stepData.turkiyedeMisinizHayir = false;



        };
});

