$(document).ready(function(){
  var query = $('.alert');
  var isVisible = query.is(':visible');
  
  if (isVisible === true) {
      $(".alert").fadeOut(8000);
    
  }     
});

function validateForm() {
  var output =false;
  var output1 =true;
  var output2 =true;
  var output3 =true;
  var output4 =true;

  username = document.form1.uname;
  lastusername = document.form1.luname;
  tckimlik = document.form1.tckimlik;
  mail = document.form1.mail;

  document.getElementById("unametxt").innerHTML = "";
  document.getElementById("lunametxt").innerHTML = "";
  document.getElementById("mailtxt").innerHTML = "";
  document.getElementById("tckimliktxt").innerHTML = "";
  
  if(!username.value) {
   // username.focus();
    document.getElementById("unametxt").innerHTML = "Boş bırakılamaz.";
    output1 = false;
  }
  if(!lastusername.value) {
    //lastusername.focus();
    document.getElementById("lunametxt").innerHTML = "Boş bırakılamaz.";
    output2 = false;
  }
  if(!tckimlik.value) {
    //password.focus();
    document.getElementById("tckimliktxt").innerHTML = "Boş bırakılamaz.";
    output3 = false;
  }
  if((tckimlik.value)){
      var tc=  /^(?=.*\d)(?=.*[0-9])(?!.*\s).{11}$/;
        if((!tckimlik.value.match(tc))) 
        { 
            document.getElementById("tckimliktxt").innerHTML = "Geçersiz Tc Kimlik Numarası.";
            output3=false;
        }
  }
  if(!mail.value) {
    //password.focus();
    document.getElementById("mailtxt").innerHTML = "Boş bırakılamaz.";
    output4 = false;
  }

 if (output1 && output2 && output3 && output4) {
      myFunction();
      document.getElementById("unametxt").innerHTML = "";
      output = true;
  }

  return output;
}

function myFunction() {
            
        var x =document.getElementById("Submit1");
        if (x.style.visibility  === "hidden") {
          x.style.visibility = "visible";
        } else {
          x.style.visibility = "hidden";
        }

      }