$(document).ready(function(){
  var query = $('.alert');
  var isVisible = query.is(':visible');
  
  if (isVisible === true) {
      $(".alert").fadeOut(80000);
    
  }     
});

function validateForm() {
  var output =false;

  username = document.form1.uname;
  password = document.form1.password;
  newPassword = document.form1.newPassword;
  new2Password = document.form1.new2Password;

  document.getElementById("unametxt").innerHTML = "";
  document.getElementById("passwordtxt").innerHTML = "";
  document.getElementById("newPasswordtxt").innerHTML = "";
  document.getElementById("new2Passwordtxt").innerHTML = "";

  if(!username.value) {
    username.focus();
    document.getElementById("unametxt").innerHTML = "Boş olamaz / Not be empty";
  }
  if(!password.value) {
    password.focus();
    document.getElementById("passwordtxt").innerHTML = "Boş olamaz / Not be empty";
  }
  if(!newPassword.value) {
    newPassword.focus();
    document.getElementById("newPasswordtxt").innerHTML = "Boş olamaz / Not be empty";
  } 
  if(!new2Password.value) {
    new2Password.focus();
    document.getElementById("new2Passwordtxt").innerHTML = "Boş olamaz / Not be empty";
  }

  if (username.value && password.value && newPassword.value && new2Password.value ) {

    output0 = unameValidation();
    output1 = passValidation(1,password.value);
    output2 = passValidation(2,newPassword.value);
    output3 = passValidation(3,new2Password.value);
    if (!output0 ) { 
      document.getElementById("unametxt").innerHTML = "Uygun bir değer giriniz. / Enter an appropriate value.";      
    } 
    if (!output1 ) { 
      document.getElementById("passwordtxt").innerHTML = "Uygun bir değer giriniz. / Enter an appropriate value.";
    } 
    if (!output2 ) { 
      document.getElementById("newPasswordtxt").innerHTML = "Uygun bir değer giriniz. / Enter an appropriate value.";
    } 
    if (!output3 ) { 
      document.getElementById("new2Passwordtxt").innerHTML = "Uygun bir değer giriniz. / Enter an appropriate value.";
    }

    //alert("output2==> "+output2);
    /*alert("output1==> "+output1);
    alert("output2==> "+output2);
    alert("output3==> "+output3);*/
    //var paswd=/^(?=.*[A-Za-z])(?=.*\d)(?=.*[.!@#$%^&*])[A-Za-z\d.!@#$%^&*]{7,20}$/;

    if(output0 && output1  && output2 && output3 && newPassword.value==new2Password.value) {
      output = true;
    }else{
      newPassword.focus();
      document.getElementById("new2Passwordtxt").innerHTML = "Yeni şifreler uyuşmadı. / The new passwords did not match";
      output = false;
    }
  }else{    
      output = false;
  }


  if (output) {
      myFunction();
      document.getElementById("unametxt").innerHTML = "";
      document.getElementById("passwordtxt").innerHTML = "";
      document.getElementById("newPasswordtxt").innerHTML = "";
      document.getElementById("new2Passwordtxt").innerHTML = "";
  }

  return output;
}

/*function validatePassword(){

    var userNameElement = document.getElementById('password');
    var helpText = document.getElementById('passwordtxt');

    var paswd=/^(?=.*[A-Za-z])(?=.*\d)(?=.*[.!@#$%^&*])[A-Za-z\d.!@#$%^&*]{7,20}$/;

    if(password.value.match(paswd))
      helpText.innerHTML = "";
    else
      helpText.innerHTML = "Invalid!";

}*/

function myFunction() {            
  var x =document.getElementById("Submit1");
  if (x.style.visibility  === "hidden") {
    x.style.visibility = "visible";
  } else {
    x.style.visibility = "hidden";
  }
}


function unameValidation()
{
    username = document.form1.uname;  
    //alert(username.value)
    if(!username.value) {
      username.focus();
      document.getElementById("unametxt").innerHTML = "Boş olamaz / Not be empty";
      return false;
    }else{
      document.getElementById("unametxt").innerHTML = "";
      return true;
    }
}

function passValidation(id,val)
{  
  if (id==1) { deger="passwordtxt"}
  else if (id==2) { deger="newPasswordtxt"}
  else if (id==3) { deger="new2Passwordtxt"}
  //alert(id) ; 
  //var format =/^(?=.*[A-Za-z])(?=.*\d)(?=.*[.!@#$%^&*])/;
  var updigit =/([A-Z])/;
  var lowdigit =/([a-z])/;
  var num =/[0-9]/;
  var spec =/[.!@#$%^&*]/;
  var turkce =/[öçğüışÖÇŞİÜĞ]/;
  var count=0;
  //var format = /[ !@#$%^&*()_+\-=\[\]{};':"\\|,.<>\/?]/;

  if (val == ''){
      document.getElementById(deger).innerHTML = "Boş olamaz / Not be empty";
      return false;
  } else {  
    if (val.length < 7){
      document.getElementById(deger).innerHTML = "En az 7 karakter / Min 7 characters";
      return false;
    }else if (val.length > 20){
      document.getElementById(deger).innerHTML = "En fazla 20 karakter/ Max 20 characters";
      return false;
    }else{
        if(val.match(turkce))
        { 
          document.getElementById(deger).innerHTML = "Türkçe karakter içermemelidir / It should not contain Turkish characters ";
          return false; 
        }

        if(val.match(updigit)){ count++; }
        if(val.match(lowdigit)){ count++; }
        if(val.match(num)){ count++; }
        if(val.match(spec)){ count++; }
        if (count <3 ) { 
          document.getElementById(deger).innerHTML = "Parola politikasına uygun değil. / Not compliant with password policy ";
          return false;
        }else{
          document.getElementById(deger).innerHTML = "";
          return true;
        }
    }
  }
}